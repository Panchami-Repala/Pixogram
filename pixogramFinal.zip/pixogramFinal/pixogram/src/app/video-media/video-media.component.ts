import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-video-media',
  templateUrl: './video-media.component.html',
  styleUrls: ['./video-media.component.css']
})
export class VideoMediaComponent implements OnInit {

  constructor(public userService:UserService) { }

  ngOnInit() {
  }

}
