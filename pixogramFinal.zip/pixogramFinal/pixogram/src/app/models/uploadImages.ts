export class UploadImages{
    public id:number;
    
    constructor(
            public image:File
    ){}
}