import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedin = false;
  username:String;
  constructor() { }
change(){
  this.isLoggedin = true;

}
change1(){
  this.isLoggedin = false;

}


}
