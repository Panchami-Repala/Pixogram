import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiMediaUploadComponent } from './multi-media-upload.component';

describe('MultiMediaUploadComponent', () => {
  let component: MultiMediaUploadComponent;
  let fixture: ComponentFixture<MultiMediaUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiMediaUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiMediaUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
