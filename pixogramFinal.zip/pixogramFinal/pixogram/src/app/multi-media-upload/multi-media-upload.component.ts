import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-multi-media-upload',
  templateUrl: './multi-media-upload.component.html',
  styleUrls: ['./multi-media-upload.component.css']
})
export class MultiMediaUploadComponent implements OnInit {

  constructor(public userService:UserService) { }

  ngOnInit() {
  }

}
