import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserService } from './user.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MediaComponent } from './media/media.component';
import { ImagesMediaComponent } from './images-media/images-media.component';
import { VideoMediaComponent } from './video-media/video-media.component';
import { SingleMediaUploadComponent } from './single-media-upload/single-media-upload.component';
import { MultiMediaUploadComponent } from './multi-media-upload/multi-media-upload.component';
import { MediaDetailsComponent } from './media-details/media-details.component';
import { FollowersComponent } from './followers/followers.component';
import { FollowingComponent } from './following/following.component';
import { NewsFeedComponent } from './news-feed/news-feed.component';
import { AccountUpdateComponent } from './account-update/account-update.component';
import { SearchComponent } from './search/search.component';
import { BlockedAccountComponent } from './blocked-account/blocked-account.component';
import { SuggestionsComponent } from './suggestions/suggestions.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    LoginComponent,
    RegisterComponent,
    MediaComponent,
    ImagesMediaComponent,
    VideoMediaComponent,
    SingleMediaUploadComponent,
    MultiMediaUploadComponent,
    MediaDetailsComponent,
    FollowersComponent,
    FollowingComponent,
    NewsFeedComponent,
    AccountUpdateComponent,
    SearchComponent,
    BlockedAccountComponent,
    SuggestionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path: '', component: HomeComponent},
      {path: 'login', component:LoginComponent},
      {path: 'register', component: RegisterComponent},
      {path: 'myMedia', component: MediaComponent},
      {path: 'images', component: ImagesMediaComponent},
      {path: 'videos', component: VideoMediaComponent},
      {path: 'uploadMedia', component:SingleMediaUploadComponent},
      {path: 'followers', component:FollowersComponent},
      {path: 'newsFeed', component: NewsFeedComponent},
      {path: 'blockedAccounts', component: BlockedAccountComponent},
      {path: 'accountUpdate', component:AccountUpdateComponent},
      {path: 'search', component:SearchComponent},
      {path: 'singleMedia', component: SingleMediaUploadComponent},
      {path: 'multipleMedia', component: MultiMediaUploadComponent},
      {path: 'following', component:FollowingComponent},
     {path: 'sugesstions', component:SuggestionsComponent}
    //  {path: 'videos', component: VideoMediaComponent},

    ]),
  ],


  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
