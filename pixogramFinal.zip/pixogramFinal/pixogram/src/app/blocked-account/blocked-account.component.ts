import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-blocked-account',
  templateUrl: './blocked-account.component.html',
  styleUrls: ['./blocked-account.component.css']
})
export class BlockedAccountComponent implements OnInit {

  constructor(public userService:UserService) { }

  ngOnInit() {
  }

}
