import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-images-media',
  templateUrl: './images-media.component.html',
  styleUrls: ['./images-media.component.css']
})
export class ImagesMediaComponent implements OnInit {

  constructor(public userService:UserService) { }

  ngOnInit() {
  }

}
