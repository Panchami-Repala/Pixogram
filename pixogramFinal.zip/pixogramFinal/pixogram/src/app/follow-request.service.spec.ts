import { TestBed } from '@angular/core/testing';

import { FollowRequestService } from './follow-request.service';

describe('FollowRequestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FollowRequestService = TestBed.get(FollowRequestService);
    expect(service).toBeTruthy();
  });
});
