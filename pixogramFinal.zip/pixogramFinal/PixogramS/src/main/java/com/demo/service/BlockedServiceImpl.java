package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Blocked;
import com.demo.repository.BlockedRepository;





@Service
public class BlockedServiceImpl implements BlockedService{

	@Autowired
	BlockedRepository blockedRepo;

	@Override
	public List<Blocked> getAllBlocked() {
		return (List<Blocked>) blockedRepo.findAll();
	}

	@Override
	public void unblockUser(Long id) {
		blockedRepo.deleteById(id);
		return;
	}

	/*
	 * @Override public Blocked blockUser11(Blocked blocked) { return
	 * blockedRepo.save(blocked); }
	 */
	@Override
	public Blocked blockUser1(Blocked block) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Blocked blockUser(Blocked block) {
		// TODO Auto-generated method stub
		return null;
	}
	/*
	 * @Override public Blocked blockUser111(Blocked block) { // TODO Auto-generated
	 * method stub return null; }
	 */
	
	
}
