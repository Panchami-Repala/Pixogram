package com.demo.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.User;
import com.demo.entity.UserFollow;
import com.demo.repository.UserFollowRepository;
import com.demo.repository.UserRepository;
import com.demo.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	 FileService fileService;
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	UserFollowRepository userFollowRepo;
	
	
	 
	
	
	@GetMapping(path = "/user")
	public List<User> getUsers() {
		System.out.println("Get all Users...");
		return (List<User>) userRepo.findAll();
	}
	
	
	
	@PostMapping(path = "/user/create")
	public User createUser(@RequestBody User user) {
		System.out.println("Creating User");
		User _user = userRepo.save(user);
		return _user;
	}

	
	@PostMapping(value = "/image")
	@ResponseStatus(HttpStatus.OK)
	public void handleFileUpload(@RequestParam("file") File file) throws IOException {
		System.out.println("Redirecting before");
		fileService.storeFile(file);
		System.out.println("Redirecting AFter");
	}
	
	
	@PostMapping(path = "/userFollow/create")
	public UserFollow createUserFollw(@RequestBody UserFollow userfollow) {
		System.out.println("Creating UserFollow");
		System.out.println(userfollow.followingId);
		UserFollow _user = userFollowRepo.save(userfollow);
		return _user;
	}
}


