package com.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.demo.entity.Blocked;



public interface BlockedRepository extends CrudRepository<Blocked, Long>{

	List<Blocked> getAllBlocked();

	Blocked blockUser(long l);

	Blocked blockUser1(Blocked b);

}
