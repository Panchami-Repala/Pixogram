package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.repository.FollowRepository;

import com.demo.entity.Follow;

@Service
public class FollowServiceImpl implements FollowService {

	@Autowired
	FollowRepository followRepo;

	
	 @Override public Follow follow(Follow follow) { return
	 followRepo.save(follow); }
	
	
	 @Override public List<Follow> getAll() { return (List<Follow>)
	followRepo.findAll(); }


	@Override
	public void unfollow(long id) {
		followRepo.deleteById(id);
		return;
	}


}
