package com.demo.service;

import java.util.List;

import com.demo.entity.Media;


public interface MediaService {

	public List<Media> getUsersMedia(int userId);

	public Media postMedia(Media m);
}
