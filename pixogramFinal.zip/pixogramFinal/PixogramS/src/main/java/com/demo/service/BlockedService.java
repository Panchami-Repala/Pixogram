package com.demo.service;

import java.util.List;

import com.demo.entity.Blocked;





public interface BlockedService {
	
	public List<Blocked> getAllBlocked(); 
	
	public void unblockUser(Long id);
	
	public Blocked blockUser(Blocked block);

	Blocked blockUser1(Blocked block);
	
}
